import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import { toast } from 'sonner';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, BookOpen } from 'lucide-react';

export default function TeacherDashboard() {
  const { currentUser } = useAuth();
  const [cards, setCards] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Form State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({ id: '', question: '', answer: '', subject_id: '' });
  const [isEditing, setIsEditing] = useState(false);

  // Filters
  const [selectedSubject, setSelectedSubject] = useState('all');

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  const fetchData = async () => {
    try {
      const fetchedSubjects = await pb.collection('subjects').getFullList({ $autoCancel: false });
      setSubjects(fetchedSubjects);

      const fetchedCards = await pb.collection('cards').getFullList({
        filter: `created_by = "${currentUser.id}"`,
        expand: 'subject_id',
        sort: '-created',
        $autoCancel: false,
      });
      setCards(fetchedCards);
    } catch (e) {
      console.error(e);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (card = null) => {
    if (card) {
      setFormData({ id: card.id, question: card.question, answer: card.answer, subject_id: card.subject_id });
      setIsEditing(true);
    } else {
      setFormData({ id: '', question: '', answer: '', subject_id: subjects[0]?.id || '' });
      setIsEditing(false);
    }
    setIsModalOpen(true);
  };

  const handleSaveCard = async (e) => {
    e.preventDefault();
    try {
      const data = {
        question: formData.question,
        answer: formData.answer,
        subject_id: formData.subject_id,
        created_by: currentUser.id,
        correct_streak: 0,
        mastered_status: false,
      };

      if (isEditing) {
        await pb.collection('cards').update(formData.id, data, { $autoCancel: false });
        toast.success('Card updated successfully');
      } else {
        await pb.collection('cards').create(data, { $autoCancel: false });
        toast.success('Card created successfully');
      }
      setIsModalOpen(false);
      fetchData();
    } catch (err) {
      toast.error('Failed to save card');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this card?")) {
      try {
        await pb.collection('cards').delete(id, { $autoCancel: false });
        toast.success('Card deleted');
        fetchData();
      } catch (err) {
        toast.error('Failed to delete card');
      }
    }
  };

  const filteredCards = selectedSubject === 'all' ? cards : cards.filter(c => c.subject_id === selectedSubject);

  return (
    <>
      <Helmet><title>Teacher Dashboard - Step Ahead Recall</title></Helmet>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">Teacher Dashboard</h1>
              <p className="text-muted-foreground">Manage cards and subjects for your students.</p>
            </div>
            <div className="flex gap-4 w-full md:w-auto">
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-[180px] bg-white">
                  <SelectValue placeholder="Filter Subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  {subjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
              
              <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => handleOpenModal()} className="rounded-xl shadow-sm">
                    <Plus className="w-5 h-5 mr-2" /> New Card
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px] rounded-3xl p-6">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold">{isEditing ? 'Edit Card' : 'Create New Card'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSaveCard} className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Subject</Label>
                      <Select value={formData.subject_id} onValueChange={(val) => setFormData({...formData, subject_id: val})} required>
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Select subject" />
                        </SelectTrigger>
                        <SelectContent>
                          {subjects.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Question</Label>
                      <Textarea required placeholder="E.g., What is the powerhouse of the cell?" 
                        value={formData.question} onChange={e => setFormData({...formData, question: e.target.value})} 
                        className="resize-none h-24 bg-white" />
                    </div>
                    <div className="space-y-2">
                      <Label>Answer</Label>
                      <Textarea required placeholder="E.g., Mitochondria" 
                        value={formData.answer} onChange={e => setFormData({...formData, answer: e.target.value})} 
                        className="resize-none h-24 bg-white" />
                    </div>
                    <DialogFooter className="mt-6">
                      <Button type="submit" className="w-full h-12 text-base rounded-xl">{isEditing ? 'Save Changes' : 'Create Card'}</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-sm border border-border overflow-hidden">
            <div className="p-6 border-b border-border bg-muted/30">
              <h2 className="font-bold text-lg flex items-center gap-2"><BookOpen className="w-5 h-5 text-primary" /> Your Cards</h2>
            </div>
            
            {loading ? (
              <div className="p-12 text-center text-muted-foreground">Loading cards...</div>
            ) : filteredCards.length === 0 ? (
              <div className="p-12 text-center">
                <p className="text-muted-foreground mb-4">No cards found. Create your first flashcard to get started.</p>
                <Button onClick={() => handleOpenModal()} variant="outline" className="rounded-xl">Create Card</Button>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filteredCards.map(card => (
                  <div key={card.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-muted/10 transition-colors">
                    <div className="flex-1">
                      <span className="text-xs font-bold text-primary uppercase tracking-wider mb-1 block">
                        {card.expand?.subject_id?.name}
                      </span>
                      <p className="font-bold text-foreground mb-1">{card.question}</p>
                      <p className="text-muted-foreground text-sm line-clamp-2">{card.answer}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={() => handleOpenModal(card)} variant="outline" size="sm" className="rounded-lg h-9">
                        <Edit2 className="w-4 h-4 mr-2" /> Edit
                      </Button>
                      <Button onClick={() => handleDelete(card.id)} variant="ghost" size="sm" className="rounded-lg h-9 text-destructive hover:text-destructive hover:bg-destructive/10">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
}