
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Brain, BookOpen, Calendar, CheckCircle, Lock, AlertCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function StudentDashboard() {
  const { currentUser, subscriptions, hasActiveSubscription } = useAuth();
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadSubjects = async () => {
      try {
        const records = await pb.collection('subjects').getFullList({ $autoCancel: false });
        setSubjects(records);
      } catch (error) {
        console.error('[Error] Failed to load subjects for StudentDashboard:', error);
        setError("Unable to load subjects. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    loadSubjects();
  }, []);

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const hasChatbotAccess = hasActiveSubscription('chatbot');
  const hasCoursesAccess = hasActiveSubscription('courses');

  return (
    <>
      <Helmet>
        <title>Dashboard - Science Tutoring Platform</title>
        <meta name="description" content="Your personal learning dashboard with access to AI tutoring and course content." />
      </Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 py-12 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-2" style={{letterSpacing: '-0.02em'}}>
                Welcome back, {currentUser?.email?.split('@')[0]}
              </h1>
              <p className="text-xl text-muted-foreground mb-12">
                Your learning dashboard
              </p>
            </motion.div>

            <div className="grid lg:grid-cols-3 gap-8 mb-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="lg:col-span-2"
              >
                <div className="bg-card rounded-2xl p-8 border shadow-sm">
                  <h2 className="text-2xl font-semibold mb-6">Active subscriptions</h2>
                  
                  {subscriptions.length === 0 ? (
                    <div className="text-center py-8">
                      <Lock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground mb-6">No active subscriptions</p>
                      <Button asChild>
                        <Link to="/subscribe">View plans</Link>
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {subscriptions.map((sub) => (
                        <div key={sub.id} className="flex items-center justify-between p-4 bg-muted rounded-xl">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                              {sub.subscriptionType === 'chatbot' ? (
                                <Brain className="w-6 h-6 text-primary" />
                              ) : (
                                <BookOpen className="w-6 h-6 text-secondary" />
                              )}
                            </div>
                            <div>
                              <h3 className="font-semibold capitalize">{sub.subscriptionType}</h3>
                              <p className="text-sm text-muted-foreground capitalize">
                                {sub.billingPeriod} subscription
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                              <Calendar className="w-4 h-4" />
                              <span>Expires: {formatDate(sub.expiryDate)}</span>
                            </div>
                            <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                              <CheckCircle className="w-3 h-3" />
                              Active
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <div className="bg-gradient-to-br from-primary to-secondary text-white rounded-2xl p-8 shadow-lg">
                  <h2 className="text-2xl font-semibold mb-4">AI Science Chatbot</h2>
                  {hasChatbotAccess ? (
                    <>
                      <p className="text-white/90 mb-6">
                        Get instant help from your AI science tutor
                      </p>
                      <Button asChild className="w-full bg-white text-primary hover:bg-white/90">
                        <Link to="/ai-chatbot">
                          <Brain className="w-4 h-4 mr-2" />
                          Start chatting
                        </Link>
                      </Button>
                    </>
                  ) : (
                    <>
                      <p className="text-white/90 mb-6">
                        Subscribe to access 24/7 AI tutoring
                      </p>
                      <Button asChild className="w-full bg-white text-primary hover:bg-white/90">
                        <Link to="/subscribe">
                          <Lock className="w-4 h-4 mr-2" />
                          Subscribe now
                        </Link>
                      </Button>
                    </>
                  )}
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-semibold">Your subjects</h2>
                {!hasCoursesAccess && (
                  <Button asChild variant="outline">
                    <Link to="/subscribe">Unlock all content</Link>
                  </Button>
                )}
              </div>

              {error ? (
                <div className="p-6 bg-destructive/10 rounded-xl border border-destructive text-destructive flex items-center gap-3">
                  <AlertCircle className="w-6 h-6" /> {error}
                </div>
              ) : loading ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="bg-card rounded-xl p-6 border animate-pulse">
                      <div className="w-12 h-12 bg-muted rounded-lg mb-4"></div>
                      <div className="h-6 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-4 bg-muted rounded w-full"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {subjects.map((subject, index) => (
                    <motion.div
                      key={subject.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.05 }}
                    >
                      <Link
                        to={`/subject/${subject.id}`}
                        className="block bg-card rounded-xl p-6 border hover:shadow-lg transition-all duration-200 h-full"
                      >
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center text-2xl">
                            {subject.icon || '🔬'}
                          </div>
                          <h3 className="text-xl font-semibold">{subject.name}</h3>
                        </div>
                        <p className="text-muted-foreground text-sm mb-4">{subject.description}</p>
                        {hasCoursesAccess ? (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                            <CheckCircle className="w-3 h-3" />
                            Full access
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-muted text-muted-foreground text-xs font-medium rounded-full">
                            <Lock className="w-3 h-3" />
                            Limited access
                          </span>
                        )}
                      </Link>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}
