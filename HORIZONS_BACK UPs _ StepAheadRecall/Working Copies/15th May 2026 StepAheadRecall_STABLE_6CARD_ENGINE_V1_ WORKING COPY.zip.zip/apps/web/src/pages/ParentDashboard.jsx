import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import Header from '@/components/Header';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Flame, CheckCircle2, TrendingUp, Calendar as CalIcon, AlertCircle } from 'lucide-react';

export default function ParentDashboard() {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({ streak: 0, mastered: 0, reviewedToday: 0 });
  const [chartData, setChartData] = useState([]);
  const [studentName, setStudentName] = useState("Your Child");

  useEffect(() => {
    async function fetchData() {
      try {
        const students = await pb.collection('users').getFullList({ filter: `role="student"`, $autoCancel: false });
        const student = students[0] || currentUser; 
        setStudentName(student.name || "Student");

        const progressRecords = await pb.collection('student_progress').getFullList({
          filter: `user_id="${student.id}"`,
          sort: '-date',
          $autoCancel: false,
        });

        // Safely fetch cards to calculate mastered count
        const cardsMastered = await pb.collection('cards').getFullList({
          filter: `mastered_status=true || correct_streak >= 6`,
          $autoCancel: false,
        });

        const todayStr = new Date().toISOString().split('T')[0];
        const todayRec = progressRecords.find(r => r.date.startsWith(todayStr)) || { streak: 0, cards_reviewed: 0 };

        setStats({
          streak: todayRec.streak || 0,
          reviewedToday: todayRec.cards_reviewed || 0,
          mastered: cardsMastered.length
        });

        // Chart Data (last 7 days)
        const cData = [];
        for (let i=6; i>=0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const dateStr = d.toISOString().split('T')[0];
          const rec = progressRecords.find(r => r.date.startsWith(dateStr));
          cData.push({
            name: d.toLocaleDateString('en-US', { weekday: 'short' }),
            reviewed: rec ? rec.cards_reviewed : 0
          });
        }
        setChartData(cData);

      } catch (e) {
        console.error("[Error] ParentDashboard fetch failed:", e);
        setError("Unable to load student progress. Please try again.");
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [currentUser]);

  return (
    <>
      <Helmet><title>Parent Dashboard - Step Ahead Recall</title></Helmet>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <div className="mb-10">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Parent Dashboard</h1>
            <p className="text-muted-foreground text-lg">Monitoring progress for <strong>{studentName}</strong></p>
          </div>

          {error ? (
             <div className="p-8 bg-card rounded-3xl border border-destructive/20 text-center shadow-sm">
                <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">Error Loading Progress</h2>
                <p className="text-muted-foreground">{error}</p>
             </div>
          ) : loading ? (
            <div className="text-center p-12 text-muted-foreground">Loading progress...</div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-border flex items-center gap-4">
                  <div className="w-14 h-14 bg-primary/10 text-primary rounded-2xl flex items-center justify-center">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="text-3xl font-extrabold">{stats.reviewedToday}</div>
                    <div className="text-sm font-semibold text-muted-foreground">Reviewed Today</div>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-sm border border-border flex items-center gap-4">
                  <div className="w-14 h-14 bg-accent/20 text-accent rounded-2xl flex items-center justify-center">
                    <Flame className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="text-3xl font-extrabold">{stats.streak}</div>
                    <div className="text-sm font-semibold text-muted-foreground">Day Streak</div>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-sm border border-border flex items-center gap-4">
                  <div className="w-14 h-14 bg-success/10 text-success rounded-2xl flex items-center justify-center">
                    <TrendingUp className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="text-3xl font-extrabold">{stats.mastered}</div>
                    <div className="text-sm font-semibold text-muted-foreground">Mastered Cards</div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-3xl p-8 shadow-sm border border-border mb-8">
                <div className="flex items-center gap-3 mb-8">
                  <CalIcon className="w-6 h-6 text-primary" />
                  <h2 className="text-2xl font-bold">Weekly Activity</h2>
                </div>
                
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#888', fontSize: 14 }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#888' }} />
                      <Tooltip cursor={{ fill: '#f7f5f2' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                      <Bar dataKey="reviewed" fill="hsl(170 74% 41%)" radius={[8, 8, 8, 8]} maxBarSize={60} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          )}
        </main>
      </div>
    </>
  );
}