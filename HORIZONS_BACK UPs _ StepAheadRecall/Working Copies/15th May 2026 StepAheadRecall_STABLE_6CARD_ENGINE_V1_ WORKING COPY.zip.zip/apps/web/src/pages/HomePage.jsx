import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { BrainCircuit, CheckCircle2, TrendingUp, ShieldCheck, ArrowRight } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function HomePage() {
  const { isAuthenticated, userRole } = useAuth();
  const navigate = useNavigate();

  const handleStartLearning = () => {
    if (isAuthenticated) {
      if (userRole === 'student') navigate('/student-home');
      else if (userRole === 'teacher') navigate('/teacher-dashboard');
      else navigate('/parent-dashboard');
    } else {
      navigate('/signup');
    }
  };

  return (
    <>
      <Helmet>
        <title>Step Ahead Recall - Master Any Subject</title>
        <meta name="description" content="Learn faster and remember longer with spaced repetition. The ultimate flashcard app for students, teachers, and parents." />
      </Helmet>
      
      <div className="min-h-screen flex flex-col bg-background">
        <Header />

        {/* Hero Section */}
        <section className="relative overflow-hidden pt-16 md:pt-24 pb-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
                className="max-w-2xl"
              >
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-6">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                  </span>
                  The smart way to learn
                </div>
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-foreground leading-[1.1] mb-6">
                  Master any subject with <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">spaced repetition</span>
                </h1>
                <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                  Stop forgetting what you learn. Our smart flashcard system schedules reviews at the exact moment you're about to forget.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button onClick={handleStartLearning} size="lg" className="h-14 px-8 text-lg rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    Start Learning Free <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                  {!isAuthenticated && (
                    <Button asChild variant="outline" size="lg" className="h-14 px-8 text-lg rounded-xl bg-white hover:bg-muted transition-colors border-border">
                      <Link to="/login">Log In</Link>
                    </Button>
                  )}
                </div>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="relative"
              >
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-secondary/20 rounded-3xl blur-3xl opacity-50"></div>
                <img 
                  src="https://images.unsplash.com/photo-1590291105887-3fc37eb18d29?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                  alt="Student using flashcards to study" 
                  className="relative rounded-3xl shadow-2xl border-4 border-white object-cover aspect-[4/3]"
                />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Step Ahead Recall works</h2>
              <p className="text-lg text-muted-foreground">Built on proven cognitive science principles to help you retain information forever.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-background p-8 rounded-3xl shadow-sm border border-border">
                <div className="w-14 h-14 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mb-6">
                  <BrainCircuit className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-3">Spaced Repetition</h3>
                <p className="text-muted-foreground leading-relaxed">
                  We show you cards right before you're likely to forget them, optimizing your memory retention.
                </p>
              </div>

              <div className="bg-background p-8 rounded-3xl shadow-sm border border-border">
                <div className="w-14 h-14 bg-accent/20 text-accent-foreground rounded-2xl flex items-center justify-center mb-6">
                  <TrendingUp className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-3">Daily Streaks</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Stay motivated with visual progress, daily streaks, and clear mastered card milestones.
                </p>
              </div>

              <div className="bg-background p-8 rounded-3xl shadow-sm border border-border">
                <div className="w-14 h-14 bg-secondary/10 text-secondary rounded-2xl flex items-center justify-center mb-6">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-3">Safe & Focused</h3>
                <p className="text-muted-foreground leading-relaxed">
                  A distraction-free environment perfect for students. Parents can track progress safely.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Roles Section (Zig-zag) */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="order-2 md:order-1 relative">
                <img 
                  src="https://images.unsplash.com/photo-1669295384050-a1d4357bd1d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Teacher checking student progress" 
                  className="rounded-3xl shadow-xl object-cover aspect-square"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Tools for Teachers & Parents</h2>
                <ul className="space-y-6 mb-8">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-success shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-lg">Create Custom Decks</h4>
                      <p className="text-muted-foreground">Teachers can easily build and assign specific topics.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-success shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-lg">Track Progress</h4>
                      <p className="text-muted-foreground">Parents can monitor daily activity, streaks, and mastery levels.</p>
                    </div>
                  </li>
                </ul>
                <Button asChild size="lg" className="rounded-xl">
                  <Link to="/signup">Create a Free Account</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}