import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient.js';
import Header from '@/components/Header.jsx';
import { Trophy, CheckCircle2, AlertCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton.jsx';

export default function MasteredCardsPage() {
  const { currentUser } = useAuth();
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      if (!currentUser) return;
      try {
        const mastered = await pb.collection('cards').getFullList({
          filter: `correct_streak >= 6 || mastered_status = true`,
          sort: '-updated',
          $autoCancel: false,
        });
        
        const validCards = mastered.filter(c => c.id && c.question);
        const verifiedCards = [];

        for (const card of validCards) {
          try {
            await pb.collection('cards').getOne(card.id, { $autoCancel: false });
            verifiedCards.push(card);
          } catch (e) {
            // Silently skip deleted cards
          }
        }

        setCards(verifiedCards);
      } catch (err) {
        setError("Failed to load your mastered cards. Please refresh.");
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [currentUser]);

  if (error) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="bg-card p-8 rounded-2xl border border-destructive shadow-sm text-center max-w-md">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Error</h2>
            <p className="text-muted-foreground">{error}</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Mastered Cards - Step Ahead Recall</title>
      </Helmet>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          
          <div className="flex flex-col mb-10">
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4 }}>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-success/10 text-success text-sm font-bold mb-4">
                <Trophy className="w-4 h-4" /> Hall of Fame
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Mastered Cards</h1>
              <p className="text-muted-foreground text-lg">You've successfully memorized {cards.length} cards permanently.</p>
            </motion.div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1,2,3,4].map(i => <Skeleton key={i} className="h-40 rounded-3xl" />)}
            </div>
          ) : cards.length === 0 ? (
            <div className="bg-card rounded-3xl p-12 text-center border border-border shadow-sm">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-muted-foreground" />
              </div>
              <h2 className="text-2xl font-bold mb-2">No mastered cards yet.</h2>
              <p className="text-muted-foreground">Keep practicing! Mastered cards will appear here once you've successfully answered them multiple times.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {cards.map((card, idx) => (
                <motion.div 
                  key={card.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                  className="bg-card rounded-3xl p-6 border border-border shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow"
                >
                  <div className="mb-4">
                    <h3 className="font-bold text-lg leading-snug">{card.question}</h3>
                  </div>
                  <div className="bg-primary/5 p-4 rounded-2xl border border-primary/10">
                    <p className="font-medium text-foreground">{card.answer}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </main>
      </div>
    </>
  );
}