import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import { ChevronRight, LayoutGrid, PlayCircle, Lock } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton.jsx';
import { Button } from '@/components/ui/button.jsx';
import { useTopicUnlock } from '@/hooks/useTopicUnlock.js';

export default function StartLearningPage() {
  const navigate = useNavigate();
  const { topics, loading } = useTopicUnlock();

  return (
    <>
      <Helmet>
        <title>Start Learning - Step Ahead Recall</title>
      </Helmet>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
            {/* Breadcrumb exact flow */}
            <div className="flex items-center text-sm font-medium text-muted-foreground mb-6">
              <span className="hover:text-foreground transition-colors cursor-pointer" onClick={() => navigate('/student-home')}>Science</span>
              <ChevronRight className="w-4 h-4 mx-1" />
              <span>Biology</span>
              <ChevronRight className="w-4 h-4 mx-1" />
              <span className="text-foreground">B1 Cell Biology</span>
            </div>

            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-secondary/10 text-secondary rounded-xl">
                    <LayoutGrid className="w-6 h-6" />
                  </div>
                  <h1 className="text-3xl md:text-4xl font-bold">
                    Start Learning
                  </h1>
                </div>
                <p className="text-muted-foreground text-lg">Your learning path for B1 Cell Biology.</p>
              </div>

              <Button 
                onClick={() => navigate('/session')}
                className="w-full md:w-auto h-14 text-lg rounded-2xl shadow-md hover:scale-[1.02] transition-transform"
                size="lg"
              >
                <PlayCircle className="w-6 h-6 mr-2 fill-current" /> Start Today's 6-Card Session
              </Button>
            </div>
          </motion.div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-40 rounded-3xl" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {topics.map((topic, idx) => (
                <motion.div 
                  key={topic.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.05 }}
                  className={`bg-card rounded-3xl p-6 border shadow-sm flex flex-col justify-between transition-all ${
                    topic.unlocked 
                      ? 'border-border opacity-100' 
                      : 'border-muted bg-muted/30 opacity-60 grayscale'
                  }`}
                >
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="font-bold text-lg leading-snug pr-4">{topic.name}</h3>
                    <div className="flex items-center shrink-0">
                      {topic.unlocked ? (
                        <div className={`w-3 h-3 rounded-full ${topic.statusColor} shadow-sm`} title="Progress indicator" />
                      ) : (
                        <div className="bg-muted-foreground/20 p-1.5 rounded-full">
                          <Lock className="w-3.5 h-3.5 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-auto pt-4 border-t border-border flex items-center justify-between">
                    <span className="text-sm font-semibold text-muted-foreground bg-muted px-3 py-1 rounded-full">
                      {topic.cardCount} {topic.cardCount === 1 ? 'card' : 'cards'}
                    </span>
                    <div className="text-sm font-bold text-muted-foreground">
                      {topic.unlocked ? (
                        <span className="text-primary">Unlocked</span>
                      ) : (
                        <span>Locked</span>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
              
              {topics.length === 0 && (
                 <div className="col-span-full py-12 text-center bg-card rounded-3xl border border-border shadow-sm">
                   <p className="text-muted-foreground font-medium text-lg">No topics available yet.</p>
                 </div>
              )}
            </div>
          )}
          
        </main>
      </div>
    </>
  );
}