import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Lock, Sparkles, Video, FileText, Brain } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function SubjectPage() {
  const { subjectId } = useParams();
  const { hasActiveSubscription } = useAuth();
  const [subject, setSubject] = useState(null);
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const subjectRecord = await pb.collection('subjects').getOne(subjectId, { $autoCancel: false });
        setSubject(subjectRecord);

        const contentRecords = await pb.collection('content').getFullList({
          filter: `subject_id = "${subjectId}"`,
          sort: '-created_at',
          $autoCancel: false
        });
        setContent(contentRecords);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [subjectId]);

  const hasCoursesAccess = hasActiveSubscription('courses');

  const getContentIcon = (type) => {
    switch (type) {
      case 'video': return <Video className="w-5 h-5" />;
      case 'notes': return <FileText className="w-5 h-5" />;
      case 'quiz': return <Brain className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading content...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <p className="text-destructive mb-4">Failed to load subject: {error}</p>
            <Button asChild>
              <Link to="/">Back to home</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${subject?.name} - Science Tutoring Platform`}</title>
        <meta name="description" content={subject?.description || 'Explore comprehensive science content'} />
      </Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />

        <section className="bg-gradient-to-r from-primary to-secondary text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center text-4xl">
                  {subject?.icon || '🔬'}
                </div>
                <h1 className="text-4xl md:text-5xl font-bold" style={{letterSpacing: '-0.02em'}}>
                  {subject?.name}
                </h1>
              </div>
              <p className="text-xl text-white/90 max-w-3xl">
                {subject?.description}
              </p>
            </motion.div>
          </div>
        </section>

        <main className="flex-1 py-12 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {content.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No content available for this subject yet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {content.map((item, index) => {
                  const isAccessible = item.is_free || hasCoursesAccess;
                  
                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.05 }}
                      className={`bg-card rounded-xl p-6 border ${
                        isAccessible ? 'hover:shadow-lg' : 'opacity-75'
                      } transition-all duration-200`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex gap-4 flex-1">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            item.is_free 
                              ? 'bg-primary/10 text-primary'
                              : 'bg-secondary/10 text-secondary'
                          }`}>
                            {getContentIcon(item.content_type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-xl font-semibold">{item.title}</h3>
                              {item.is_free && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-primary/10 text-primary text-xs font-medium rounded-full">
                                  <Sparkles className="w-3 h-3" />
                                  Free
                                </span>
                              )}
                              {!isAccessible && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-muted text-muted-foreground text-xs font-medium rounded-full">
                                  <Lock className="w-3 h-3" />
                                  Premium
                                </span>
                              )}
                            </div>
                            <p className="text-muted-foreground mb-4">{item.description}</p>
                            <p className="text-sm text-muted-foreground capitalize">
                              Type: {item.content_type}
                            </p>
                          </div>
                        </div>
                        <div className="flex-shrink-0">
                          {isAccessible ? (
                            <Button asChild>
                              <Link to={`/content/${item.id}`}>
                                View content
                              </Link>
                            </Button>
                          ) : (
                            <Button asChild variant="outline">
                              <Link to="/subscribe">
                                <Lock className="w-4 h-4 mr-2" />
                                Subscribe to unlock
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {!hasCoursesAccess && (
              <div className="mt-12 bg-gradient-to-r from-primary to-secondary text-white rounded-2xl p-8 text-center">
                <h2 className="text-2xl md:text-3xl font-bold mb-4">Unlock all content</h2>
                <p className="text-white/90 mb-6 max-w-2xl mx-auto">
                  Subscribe to get unlimited access to all videos, notes, and quizzes across all subjects
                </p>
                <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                  <Link to="/subscribe">View subscription plans</Link>
                </Button>
              </div>
            )}
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}