
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient.js';
import { Button } from '@/components/ui/button.jsx';
import { X, Check, Eye, AlertCircle, CircleDot, Trophy } from 'lucide-react';
import { useSessionBuilder, saveSessionDate } from '@/hooks/useSessionBuilder.js';
import { setCardProgress } from '@/lib/localCards.js';

export default function SessionPage() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const { sessionCards: cards, sessionComposition, loading } = useSessionBuilder();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [sessionStats, setSessionStats] = useState({ reviewed: 0, mastered: 0, knew: 0, nearly: 0, forgot: 0 });
  const [showMasteryAnim, setShowMasteryAnim] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const reviewedCountRef = useRef(0);

  const handleReview = async (type) => {
    if (isProcessing || !currentUser) return;
    setIsProcessing(true);

    const card = cards[currentIndex];
    reviewedCountRef.current += 1;

    const isCorrect = type === 'knew';
    const currentProgress = card.progress;
    
    let newStage = currentProgress.stage;
    let newStreak = currentProgress.correctStreak;
    let nextDays = 0;
    let mastered = false;

    if (isCorrect) {
      newStage += 1;
      newStreak += 1;
      
      if (newStage === 1) nextDays = 1;
      else if (newStage === 2) nextDays = 3;
      else if (newStage === 3) nextDays = 7;
      else if (newStage === 4) nextDays = 14;
      else { nextDays = 30; mastered = true; }
    } else {
      newStreak = 0;
      newStage = Math.max(0, newStage - 1);
      nextDays = 2;
    }

    const now = new Date();
    const nextDate = new Date(now.getTime() + nextDays * 24 * 60 * 60 * 1000);

    const updatedProgress = {
      stage: newStage,
      correctStreak: newStreak,
      nextReviewDate: nextDate.toISOString(),
      lastReviewDate: now.toISOString(),
      isNew: false
    };

    // Save to localStorage with student identifier
    const studentIdentifier = currentUser.id || currentUser.name;
    setCardProgress(card.id, updatedProgress, studentIdentifier);

    const newStats = {
      reviewed: reviewedCountRef.current,
      mastered: sessionStats.mastered + (mastered ? 1 : 0),
      knew: sessionStats.knew + (type === 'knew' ? 1 : 0),
      nearly: sessionStats.nearly + (type === 'nearly' ? 1 : 0),
      forgot: sessionStats.forgot + (type === 'forgot' ? 1 : 0)
    };

    setSessionStats(newStats);

    if (mastered) {
      setShowMasteryAnim(true);
      setTimeout(() => {
        setShowMasteryAnim(false);
        advanceCard(newStats);
      }, 1500);
    } else {
      advanceCard(newStats);
    }
  };

  const advanceCard = async (finalStats) => {
    if (currentIndex + 1 < cards.length) {
      setShowAnswer(false);
      setCurrentIndex(prev => prev + 1);
      setIsProcessing(false);
    } else {
      try {
        const now = new Date();
        const streakUpdated = reviewedCountRef.current >= 5;
        
        await pb.collection('sessions').create({
          user_id: currentUser.id,
          date: now.toISOString().replace('T', ' '),
          cards_reviewed: reviewedCountRef.current,
          streak_updated: streakUpdated
        }, { $autoCancel: false });
      } catch (err) {
        // Silently skip session creation failures
      }

      // Session is complete, lock the date now
      const studentIdentifier = currentUser.id || currentUser.name;
      saveSessionDate(studentIdentifier);

      navigate('/session-complete', { 
        state: { 
          stats: finalStats,
          composition: sessionComposition
        } 
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-muted-foreground font-medium">Building your custom session...</p>
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <>
        <Helmet>
          <title>Session Empty - Step Ahead Recall</title>
        </Helmet>
        <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
          <div className="bg-card w-full max-w-md p-8 md:p-10 rounded-3xl shadow-sm border border-border text-center">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertCircle className="w-10 h-10 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-bold mb-3">Session Unavailable</h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              No valid cards available for this session. You might have mastered them all or none are due!
            </p>
            <Button 
              onClick={() => navigate('/student-home')} 
              className="w-full h-14 text-lg rounded-2xl shadow-sm"
            >
              Return to Home
            </Button>
          </div>
        </div>
      </>
    );
  }

  const currentCard = cards[currentIndex];
  
  if (!currentCard) return null;

  const progressPercent = Math.round(((currentIndex) / cards.length) * 100);

  return (
    <>
      <Helmet>
        <title>Review Session - Step Ahead Recall</title>
      </Helmet>
      <div className="min-h-screen bg-background flex flex-col items-center p-4 relative">
        
        <AnimatePresence>
          {showMasteryAnim && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm"
            >
              <div className="text-center animate-mastery-pop">
                <div className="w-32 h-32 bg-accent/20 text-accent-foreground rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                  <Trophy className="w-16 h-16 text-accent" />
                </div>
                <h2 className="text-4xl font-extrabold text-foreground mb-2">Mastered!</h2>
                <p className="text-xl text-muted-foreground">You've memorized this card.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="w-full max-w-3xl flex flex-col gap-4 py-6 mb-4">
          <div className="flex justify-between items-center">
            <Button variant="ghost" onClick={() => navigate('/student-home')} className="text-muted-foreground rounded-xl">
              <X className="w-6 h-6 mr-2" /> Exit
            </Button>
            <div className="text-sm font-bold bg-muted px-4 py-2 rounded-full text-muted-foreground font-variant-tabular">
              {currentIndex + 1} of {cards.length} cards
            </div>
          </div>
          
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="flex-1 w-full max-w-2xl flex flex-col justify-center gap-8 relative pb-32">
          
          <AnimatePresence mode="wait">
            <motion.div
              key={currentCard.id + '-q'}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="w-full"
            >
              <div className="bg-white min-h-[300px] rounded-3xl shadow-md border border-border p-8 md:p-12 flex items-center justify-center text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary to-secondary opacity-50"></div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground leading-snug">
                  {currentCard.question}
                </h2>
              </div>
            </motion.div>
          </AnimatePresence>

          <AnimatePresence>
            {showAnswer && (
              <motion.div
                key={currentCard.id + '-a'}
                initial={{ opacity: 0, height: 0, y: -20 }}
                animate={{ opacity: 1, height: 'auto', y: 0 }}
                transition={{ duration: 0.4, type: 'spring', bounce: 0.4 }}
                className="w-full overflow-hidden"
              >
                <div className="bg-primary/5 min-h-[150px] rounded-3xl shadow-sm border border-primary/10 p-8 md:p-10 flex items-center justify-center text-center">
                  <p className="text-2xl md:text-3xl font-bold text-foreground">
                    {currentCard.answer}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>

        <div className="fixed bottom-0 left-0 w-full p-4 bg-background/95 backdrop-blur-md border-t border-border flex justify-center z-10">
          <div className="w-full max-w-2xl">
            {!showAnswer ? (
              <Button 
                onClick={() => setShowAnswer(true)} 
                disabled={isProcessing}
                className="w-full h-[72px] text-2xl font-bold rounded-2xl shadow-lg hover:shadow-xl transition-shadow disabled:opacity-50"
              >
                <Eye className="w-7 h-7 mr-3" /> Reveal Answer
              </Button>
            ) : (
              <div className="flex gap-3 sm:gap-4">
                <Button 
                  onClick={() => handleReview('forgot')}
                  disabled={isProcessing}
                  className="flex-1 h-[72px] text-lg sm:text-xl font-bold rounded-2xl shadow-lg bg-again hover:brightness-110 text-white transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  <X className="w-6 h-6 sm:mr-2" /> <span className="hidden sm:inline">I forgot</span>
                </Button>
                <Button 
                  onClick={() => handleReview('nearly')}
                  disabled={isProcessing}
                  className="flex-1 h-[72px] text-lg sm:text-xl font-bold rounded-2xl shadow-lg bg-hard hover:brightness-110 text-white transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  <CircleDot className="w-6 h-6 sm:mr-2" /> <span className="hidden sm:inline">Nearly</span>
                </Button>
                <Button 
                  onClick={() => handleReview('knew')}
                  disabled={isProcessing}
                  className="flex-1 h-[72px] text-lg sm:text-xl font-bold rounded-2xl shadow-lg bg-easy hover:brightness-110 text-white transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  <Check className="w-6 h-6 sm:mr-2" /> <span className="hidden sm:inline">I knew it</span>
                </Button>
              </div>
            )}
          </div>
        </div>

      </div>
    </>
  );
}
