import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { User, LogOut, Lock } from 'lucide-react';

export default function SettingsPage() {
  const { currentUser, logout } = useAuth();
  const [profileData, setProfileData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || ''
  });
  const [passData, setPassData] = useState({
    oldPassword: '',
    password: '',
    passwordConfirm: ''
  });
  const [loading, setLoading] = useState(false);

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await pb.collection('users').update(currentUser.id, profileData, { $autoCancel: false });
      toast.success('Profile updated successfully');
    } catch (err) {
      toast.error(err.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordUpdate = async (e) => {
    e.preventDefault();
    if (passData.password !== passData.passwordConfirm) {
      toast.error('New passwords do not match');
      return;
    }
    setLoading(true);
    try {
      await pb.collection('users').update(currentUser.id, {
        oldPassword: passData.oldPassword,
        password: passData.password,
        passwordConfirm: passData.passwordConfirm
      }, { $autoCancel: false });
      toast.success('Password changed successfully');
      setPassData({ oldPassword: '', password: '', passwordConfirm: '' });
    } catch (err) {
      toast.error(err.message || 'Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>Settings - Step Ahead Recall</title></Helmet>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 max-w-3xl mx-auto w-full px-4 sm:px-6 py-8 md:py-12 space-y-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2">Account Settings</h1>
            <p className="text-muted-foreground">Manage your personal info and security.</p>
          </div>

          <div className="bg-white rounded-3xl p-8 border border-border shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <User className="w-6 h-6 text-primary" />
              <h2 className="text-xl font-bold">Profile Details</h2>
            </div>
            
            <form onSubmit={handleProfileUpdate} className="space-y-4 max-w-md">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input 
                  value={profileData.name} 
                  onChange={e => setProfileData({...profileData, name: e.target.value})} 
                  className="h-12 rounded-xl bg-background" 
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input 
                  type="email" 
                  value={profileData.email} 
                  onChange={e => setProfileData({...profileData, email: e.target.value})} 
                  className="h-12 rounded-xl bg-background" 
                />
              </div>
              <div className="pt-2">
                <span className="inline-block px-3 py-1 bg-muted text-xs font-bold rounded-full uppercase tracking-wider">
                  Role: {currentUser?.role}
                </span>
              </div>
              <Button type="submit" disabled={loading} className="rounded-xl mt-4">Save Changes</Button>
            </form>
          </div>

          <div className="bg-white rounded-3xl p-8 border border-border shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Lock className="w-6 h-6 text-primary" />
              <h2 className="text-xl font-bold">Change Password</h2>
            </div>
            
            <form onSubmit={handlePasswordUpdate} className="space-y-4 max-w-md">
              <div className="space-y-2">
                <Label>Current Password</Label>
                <Input 
                  type="password" 
                  value={passData.oldPassword} 
                  onChange={e => setPassData({...passData, oldPassword: e.target.value})} 
                  className="h-12 rounded-xl bg-background" 
                  required 
                />
              </div>
              <div className="space-y-2">
                <Label>New Password</Label>
                <Input 
                  type="password" 
                  value={passData.password} 
                  onChange={e => setPassData({...passData, password: e.target.value})} 
                  className="h-12 rounded-xl bg-background" 
                  required minLength={8}
                />
              </div>
              <div className="space-y-2">
                <Label>Confirm New Password</Label>
                <Input 
                  type="password" 
                  value={passData.passwordConfirm} 
                  onChange={e => setPassData({...passData, passwordConfirm: e.target.value})} 
                  className="h-12 rounded-xl bg-background" 
                  required minLength={8}
                />
              </div>
              <Button type="submit" variant="secondary" disabled={loading} className="rounded-xl mt-4">Update Password</Button>
            </form>
          </div>

          <div className="pt-4 border-t border-border">
            <Button onClick={logout} variant="destructive" className="rounded-xl h-12 px-6 shadow-sm">
              <LogOut className="w-5 h-5 mr-2" /> Log Out
            </Button>
          </div>

        </main>
      </div>
    </>
  );
}