import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Lock, ArrowLeft, CheckCircle, XCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function ContentPlayer() {
  const { contentId } = useParams();
  const { hasActiveSubscription } = useAuth();
  const [content, setContent] = useState(null);
  const [subject, setSubject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  useEffect(() => {
    const loadContent = async () => {
      try {
        const contentRecord = await pb.collection('content').getOne(contentId, { 
          expand: 'subject_id',
          $autoCancel: false 
        });
        setContent(contentRecord);
        
        if (contentRecord.expand?.subject_id) {
          setSubject(contentRecord.expand.subject_id);
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadContent();
  }, [contentId]);

  const hasCoursesAccess = hasActiveSubscription('courses');
  const isAccessible = content?.is_free || hasCoursesAccess;

  const handleQuizAnswer = (questionIndex, selectedOption) => {
    setQuizAnswers(prev => ({
      ...prev,
      [questionIndex]: selectedOption
    }));
  };

  const handleQuizSubmit = () => {
    if (!content?.content_data?.questions) return;
    
    let correct = 0;
    content.content_data.questions.forEach((question, index) => {
      if (quizAnswers[index] === question.correctAnswer) {
        correct++;
      }
    });
    
    setQuizScore(correct);
    setQuizSubmitted(true);
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading content...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <p className="text-destructive mb-4">Failed to load content: {error}</p>
            <Button asChild>
              <Link to="/">Back to home</Link>
            </Button>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (!isAccessible) {
    return (
      <>
        <Helmet>
          <title>{`${content?.title} - Science Tutoring Platform`}</title>
          <meta name="description" content="Premium content - subscription required" />
        </Helmet>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1 flex items-center justify-center py-12 px-4">
            <div className="text-center max-w-md">
              <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Lock className="w-8 h-8 text-muted-foreground" />
              </div>
              <h1 className="text-3xl font-bold mb-4">Subscribe to unlock</h1>
              <p className="text-muted-foreground mb-2">
                This content requires an active Courses subscription
              </p>
              <p className="font-semibold mb-8">{content?.title}</p>
              <Button asChild size="lg">
                <Link to="/subscribe">View subscription plans</Link>
              </Button>
            </div>
          </main>
          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${content?.title} - Science Tutoring Platform`}</title>
        <meta name="description" content={content?.description || 'Science learning content'} />
      </Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 py-12 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <Button asChild variant="outline" className="mb-6">
              <Link to={subject ? `/subject/${subject.id}` : '/'}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to {subject?.name || 'home'}
              </Link>
            </Button>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="bg-card rounded-2xl p-8 border shadow-sm">
                <div className="mb-6">
                  <h1 className="text-3xl md:text-4xl font-bold mb-2" style={{letterSpacing: '-0.02em'}}>
                    {content?.title}
                  </h1>
                  <p className="text-muted-foreground">{content?.description}</p>
                </div>

                {content?.content_type === 'video' && (
                  <div className="space-y-6">
                    {content.content_url ? (
                      <div className="aspect-video bg-muted rounded-xl flex items-center justify-center">
                        <a 
                          href={content.content_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          Open video in new tab
                        </a>
                      </div>
                    ) : (
                      <div className="aspect-video bg-muted rounded-xl flex items-center justify-center">
                        <p className="text-muted-foreground">Video content placeholder</p>
                      </div>
                    )}
                  </div>
                )}

                {content?.content_type === 'notes' && (
                  <div className="prose max-w-none">
                    {content.content_url ? (
                      <div className="space-y-4">
                        <p className="text-muted-foreground">Study notes for this topic:</p>
                        <a 
                          href={content.content_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          Open notes document
                        </a>
                      </div>
                    ) : (
                      <p className="text-muted-foreground">Study notes content would appear here</p>
                    )}
                  </div>
                )}

                {content?.content_type === 'quiz' && content?.content_data?.questions && (
                  <div className="space-y-6">
                    {content.content_data.questions.map((question, index) => (
                      <div key={index} className="p-6 bg-muted rounded-xl">
                        <h3 className="font-semibold mb-4">
                          {index + 1}. {question.question}
                        </h3>
                        <div className="space-y-2">
                          {question.options.map((option, optIndex) => {
                            const isSelected = quizAnswers[index] === optIndex;
                            const isCorrect = optIndex === question.correctAnswer;
                            const showResult = quizSubmitted;
                            
                            return (
                              <button
                                key={optIndex}
                                onClick={() => !quizSubmitted && handleQuizAnswer(index, optIndex)}
                                disabled={quizSubmitted}
                                className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                                  showResult && isCorrect
                                    ? 'border-primary bg-primary/10'
                                    : showResult && isSelected && !isCorrect
                                    ? 'border-destructive bg-destructive/10'
                                    : isSelected
                                    ? 'border-primary bg-primary/5'
                                    : 'border-border hover:border-primary/50'
                                } ${quizSubmitted ? 'cursor-default' : 'cursor-pointer'}`}
                              >
                                <div className="flex items-center justify-between">
                                  <span>{option}</span>
                                  {showResult && isCorrect && (
                                    <CheckCircle className="w-5 h-5 text-primary" />
                                  )}
                                  {showResult && isSelected && !isCorrect && (
                                    <XCircle className="w-5 h-5 text-destructive" />
                                  )}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}

                    {!quizSubmitted ? (
                      <Button 
                        onClick={handleQuizSubmit}
                        disabled={Object.keys(quizAnswers).length !== content.content_data.questions.length}
                        className="w-full"
                      >
                        Submit answers
                      </Button>
                    ) : (
                      <div className="text-center p-6 bg-primary/10 rounded-xl">
                        <h3 className="text-2xl font-bold mb-2">
                          Your score: {quizScore} / {content.content_data.questions.length}
                        </h3>
                        <p className="text-muted-foreground mb-4">
                          {(quizScore / content.content_data.questions.length) >= 0.7 
                            ? 'Great work! You have a strong understanding of this topic.'
                            : 'Keep practicing! Review the material and try again.'}
                        </p>
                        <Button 
                          onClick={() => {
                            setQuizAnswers({});
                            setQuizSubmitted(false);
                          }}
                        >
                          Try again
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}