
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle2, ArrowRight, Trophy, Flame } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient.js';

export default function SessionCompletePage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser } = useAuth();
  const stats = location.state?.stats || { reviewed: 0, mastered: 0, knew: 0, nearly: 0, forgot: 0 };
  
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    if (currentUser) {
      pb.collection('student_progress').getFirstListItem(`user_id="${currentUser.id}"`, { $autoCancel: false })
        .then(res => setStreak(res.streak || 0))
        .catch(() => setStreak(0));
    }
  }, [currentUser]);

  return (
    <>
      <Helmet>
        <title>Session Complete - Step Ahead Recall</title>
      </Helmet>
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="bg-card w-full max-w-md p-8 md:p-12 rounded-[2.5rem] shadow-xl border border-border text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-success via-primary to-accent"></div>
          
          <div className="w-24 h-24 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
            <CheckCircle2 className="w-12 h-12 text-success" />
          </div>
          
          <h1 className="text-3xl font-extrabold mb-3">Session Complete!</h1>
          <p className="text-foreground text-lg mb-1 font-medium">
            You completed today's {stats.reviewed}-card session.
          </p>
          <p className="text-muted-foreground text-md mb-10">
            You're building long-term memory.
          </p>

          <div className="grid grid-cols-3 gap-3 mb-10">
            <div className="bg-muted/50 rounded-2xl p-4 flex flex-col items-center justify-center border border-border/50">
              <span className="text-2xl font-black text-foreground mb-1">{stats.reviewed}</span>
              <span className="text-xs font-semibold text-muted-foreground text-center">
                {stats.reviewed === 1 ? 'Card' : 'Cards'}<br/>Reviewed
              </span>
            </div>
            <div className="bg-accent/10 rounded-2xl p-4 flex flex-col items-center justify-center border border-accent/20">
              <span className="text-2xl font-black text-accent-foreground mb-1 flex items-center gap-1">
                {stats.mastered} <Trophy className="w-4 h-4 text-accent" />
              </span>
              <span className="text-xs font-semibold text-accent-foreground text-center">
                Newly<br/>Mastered
              </span>
            </div>
            <div className="bg-primary/10 rounded-2xl p-4 flex flex-col items-center justify-center border border-primary/20">
              <span className="text-2xl font-black text-primary mb-1 flex items-center gap-1">
                {streak} <Flame className="w-4 h-4 text-primary" />
              </span>
              <span className="text-xs font-semibold text-primary text-center">
                Day<br/>Streak
              </span>
            </div>
          </div>

          <Button 
            onClick={() => navigate('/student-home')}
            className="w-full h-16 text-xl font-bold rounded-2xl shadow-lg hover:scale-[1.02] transition-transform"
          >
            Return to Dashboard <ArrowRight className="w-6 h-6 ml-2" />
          </Button>
        </motion.div>
      </div>
    </>
  );
}
