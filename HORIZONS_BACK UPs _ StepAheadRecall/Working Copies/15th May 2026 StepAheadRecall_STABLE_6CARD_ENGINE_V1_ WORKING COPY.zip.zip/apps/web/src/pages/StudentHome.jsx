
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { localCards, getCardProgress } from '@/lib/localCards.js';
import Header from '@/components/Header.jsx';
import { Button } from '@/components/ui/button.jsx';
import { PlayCircle, Flame, BookOpen, CheckCircle, Lock, AlertCircle, RefreshCw } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton.jsx';
import { useSessionBuilder, getStudentIdentifier, isSessionAvailableToday, clearSessionDate } from '@/hooks/useSessionBuilder.js';
import { useTopicUnlock } from '@/hooks/useTopicUnlock.js';

export default function StudentHome() {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({ streak: 0, mastered: 0, totalCards: 0 });

  const { sessionCards, loading: sessionLoading, refreshSession } = useSessionBuilder();
  const { topics, loading: topicsLoading } = useTopicUnlock();

  const studentIdentifier = getStudentIdentifier(currentUser);
  const sessionAvailable = isSessionAvailableToday(studentIdentifier);

  const fetchStats = useCallback(async () => {
    if (!currentUser) return;
    try {
      const totalCards = localCards.length;
      
      // Re-evaluate mastery based on actual progress logic for this student
      const masteredCards = localCards.filter(c => {
        const prog = getCardProgress(c.id, studentIdentifier);
        return prog.stage >= 5;
      });

      // Mock streak data
      const mockStreak = 3;

      setStats({
        streak: mockStreak,
        mastered: masteredCards.length,
        totalCards: totalCards
      });
    } catch (err) {
      setError("Unable to load card statistics. Please try refreshing.");
    } finally {
      setLoading(false);
    }
  }, [currentUser, studentIdentifier]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  const handleResetProgress = () => {
    if (!currentUser) return;
    
    if (window.confirm('Are you sure you want to reset all your card progress? This cannot be undone.')) {
      const keyToClear = `stepAheadRecall_progress_${studentIdentifier}`;
      
      console.log('Clearing student-specific localStorage key:', keyToClear);
      localStorage.removeItem(keyToClear);
      
      console.log('Clearing old global localStorage key: cardProgress');
      localStorage.removeItem('cardProgress');
      
      clearSessionDate(studentIdentifier);
      console.log(`Cleared session date for student ${studentIdentifier}`);
      
      // Immediately recalculate available cards and update state
      refreshSession();
      
      // Re-fetch stats to update the mastered count display
      fetchStats();
      
      toast.success('Progress successfully reset');
    }
  };

  const progressPercent = stats.totalCards > 0 ? Math.round((stats.mastered / stats.totalCards) * 100) : 0;
  const isReady = !loading && !sessionLoading && !topicsLoading;

  if (error) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="bg-card p-8 rounded-2xl border border-destructive shadow-sm text-center max-w-md">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Error Loading Data</h2>
            <p className="text-muted-foreground">{error}</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - Step Ahead Recall</title>
      </Helmet>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        
        <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">
                Welcome back, {currentUser?.name?.split(' ')[0] || 'Student'}!
              </h1>
              <p className="text-muted-foreground text-lg">Ready to crush your learning goals today?</p>
            </div>
            <Button 
              variant="outline" 
              onClick={handleResetProgress}
              className="text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/20 self-start sm:self-auto"
            >
              <RefreshCw className="w-4 h-4 mr-2" /> Reset Progress
            </Button>
          </motion.div>

          {!isReady ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              <Skeleton className="h-32 rounded-3xl" />
              <Skeleton className="h-32 rounded-3xl" />
              <Skeleton className="h-32 rounded-3xl" />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mb-10">
              <div className="bg-card rounded-3xl p-6 shadow-sm border border-border flex flex-col justify-between">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-primary/10 text-primary rounded-xl"><PlayCircle className="w-6 h-6" /></div>
                  <h3 className="font-semibold text-lg">Session Cards</h3>
                </div>
                <div>
                  {sessionCards.length === 0 && !sessionAvailable ? (
                    <span className="text-muted-foreground font-medium">All done for today! Come back tomorrow for more cards.</span>
                  ) : (
                    <>
                      <span className="text-4xl font-extrabold text-foreground">{sessionCards.length}</span>
                      <span className="text-muted-foreground ml-2 font-medium">ready</span>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-card rounded-3xl p-6 shadow-sm border border-border flex flex-col justify-between">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-accent/20 text-accent-foreground rounded-xl"><Flame className="w-6 h-6 text-accent" /></div>
                  <h3 className="font-semibold text-lg">Daily Streak</h3>
                </div>
                <div>
                  <span className="text-4xl font-extrabold text-foreground">{stats.streak}</span>
                  <span className="text-muted-foreground ml-2 font-medium">days</span>
                </div>
              </div>

              <div className="bg-card rounded-3xl p-6 shadow-sm border border-border flex flex-col justify-between sm:col-span-2 md:col-span-1">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-success/10 text-success rounded-xl"><BookOpen className="w-6 h-6" /></div>
                  <h3 className="font-semibold text-lg">Mastered</h3>
                </div>
                <div>
                  <span className="text-4xl font-extrabold text-foreground">{stats.mastered}</span>
                  <span className="text-muted-foreground ml-2 font-medium">cards</span>
                </div>
              </div>
            </div>
          )}

          {isReady && (
            <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4, delay: 0.1 }}>
              <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-md border border-border text-center mb-12">
                <h2 className="text-2xl font-bold mb-6">Overall Mastery Progress</h2>
                
                <div className="w-full bg-muted rounded-full h-6 mb-4 overflow-hidden shadow-inner">
                  <div 
                    className="bg-primary h-full rounded-full transition-all duration-1000 ease-out flex items-center justify-end px-2"
                    style={{ width: `${Math.max(progressPercent, 5)}%` }}
                  >
                    {progressPercent > 10 && <span className="text-[10px] font-bold text-white">{progressPercent}%</span>}
                  </div>
                </div>
                <p className="text-muted-foreground mb-8 font-medium">
                  {stats.mastered} of {stats.totalCards} cards mastered
                </p>

                <div className="flex justify-center mt-2 mb-12">
                  <Button 
                    onClick={() => navigate('/session')}
                    disabled={sessionCards.length === 0}
                    className="w-full sm:w-auto min-w-[280px] h-16 text-xl rounded-2xl shadow-lg hover:scale-[1.02] transition-transform disabled:hover:scale-100"
                    size="lg"
                  >
                    {sessionCards.length === 0 ? (
                      <span className="flex items-center gap-2"><CheckCircle className="w-6 h-6" /> All done for today!</span>
                    ) : (
                      <span className="flex items-center gap-2"><PlayCircle className="w-6 h-6 fill-current" /> Start Today's {sessionCards.length}-Card Session</span>
                    )}
                  </Button>
                </div>

                <div className="text-left mt-12 border-t border-border pt-10">
                  <h3 className="text-2xl font-bold mb-6">B1 Cell Biology Roadmap</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {topics.map((topic) => (
                      <div 
                        key={topic.id}
                        className={`bg-card rounded-3xl p-6 border shadow-sm flex flex-col justify-between transition-all ${
                          topic.unlocked 
                            ? 'border-border opacity-100' 
                            : 'border-muted bg-muted/30 opacity-60 grayscale'
                        }`}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <h4 className="font-bold text-lg leading-snug pr-4">{topic.name}</h4>
                          <div className="flex items-center shrink-0">
                            {topic.unlocked ? (
                              <div className={`w-3 h-3 rounded-full ${topic.statusColor} shadow-sm`} title="Progress indicator" />
                            ) : (
                              <div className="bg-muted-foreground/20 p-1.5 rounded-full">
                                <Lock className="w-3.5 h-3.5 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="mt-auto pt-4 border-t border-border flex items-center justify-between">
                          <span className="text-sm font-semibold text-muted-foreground bg-muted px-3 py-1 rounded-full">
                            {topic.cardCount} {topic.cardCount === 1 ? 'card' : 'cards'}
                          </span>
                          <div className="text-sm font-bold text-muted-foreground">
                            {topic.unlocked ? (
                              <span className="text-primary">Unlocked</span>
                            ) : (
                              <span>Locked</span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </motion.div>
          )}
          
        </main>
      </div>
    </>
  );
}
