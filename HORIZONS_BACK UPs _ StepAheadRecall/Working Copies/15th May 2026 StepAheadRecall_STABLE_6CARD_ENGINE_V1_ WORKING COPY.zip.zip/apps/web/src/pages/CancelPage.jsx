import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { XCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function CancelPage() {
  return (
    <>
      <Helmet>
        <title>Payment cancelled - Science Tutoring Platform</title>
        <meta name="description" content="Your payment was cancelled." />
      </Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center py-12 px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-md"
          >
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
              <XCircle className="w-12 h-12 text-muted-foreground" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Payment cancelled</h1>
            <p className="text-muted-foreground mb-8">
              Your payment was not completed. No charges have been made to your account.
            </p>
            <div className="space-y-3">
              <Button asChild className="w-full" size="lg">
                <Link to="/subscribe">Try again</Link>
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link to="/">Back to home</Link>
              </Button>
            </div>
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
}