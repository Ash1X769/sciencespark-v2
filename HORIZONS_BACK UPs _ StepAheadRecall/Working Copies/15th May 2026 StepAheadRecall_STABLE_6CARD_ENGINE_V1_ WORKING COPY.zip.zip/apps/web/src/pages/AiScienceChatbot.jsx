import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Lock } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import IntegratedAiChat from '@/components/integrated-ai-chat';

export default function AiScienceChatbot() {
  const { hasActiveSubscription } = useAuth();
  const hasChatbotAccess = hasActiveSubscription('chatbot');

  if (!hasChatbotAccess) {
    return (
      <>
        <Helmet>
          <title>AI Science Chatbot - Science Tutoring Platform</title>
          <meta name="description" content="Get instant help from our AI-powered GCSE and KS3 Science tutor." />
        </Helmet>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1 flex items-center justify-center py-12 px-4">
            <div className="text-center max-w-md">
              <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Lock className="w-8 h-8 text-muted-foreground" />
              </div>
              <h1 className="text-3xl font-bold mb-4">Subscription required</h1>
              <p className="text-muted-foreground mb-8">
                Subscribe to the AI Chatbot plan to access your personal science tutor
              </p>
              <Button asChild size="lg">
                <Link to="/subscribe">View subscription plans</Link>
              </Button>
            </div>
          </main>
          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>AI Science Chatbot - Science Tutoring Platform</title>
        <meta name="description" content="Get instant help from our AI-powered GCSE and KS3 Science tutor." />
      </Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-2" style={{letterSpacing: '-0.02em'}}>
                GCSE/KS3 Science Tutor
              </h1>
              <p className="text-muted-foreground">
                Ask me anything about Biology, Chemistry, or Physics
              </p>
            </div>
            <div className="bg-card rounded-2xl border shadow-sm h-[calc(100vh-280px)]">
              <IntegratedAiChat />
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </>
  );
}