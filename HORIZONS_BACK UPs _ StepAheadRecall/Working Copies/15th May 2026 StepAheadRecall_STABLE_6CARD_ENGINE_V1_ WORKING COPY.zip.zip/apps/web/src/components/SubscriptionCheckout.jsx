import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import apiServerClient from '@/lib/apiServerClient';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

export default function SubscriptionCheckout({ tier }) {
  const { isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleCheckout = async () => {
    if (!isAuthenticated) {
      toast({
        title: 'Authentication required',
        description: 'Please log in to subscribe',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);

    try {
      const amount = tier.billingPeriod === 'yearly' ? 7500 : tier.subscriptionType === 'chatbot' ? 500 : 1000;

      const response = await apiServerClient.fetch('/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          productName: tier.name,
          subscriptionType: tier.subscriptionType,
          billingPeriod: tier.billingPeriod,
          successUrl: `${window.location.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${window.location.origin}/cancel`
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create checkout session');
      }

      const data = await response.json();
      window.open(data.url, '_blank');
    } catch (error) {
      toast({
        title: 'Checkout failed',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button onClick={handleCheckout} disabled={loading} className="w-full">
      {loading ? 'Processing...' : tier.cta}
    </Button>
  );
}