import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

export default function ProtectedRoute({ children, allowedRoles }) {
  const { isAuthenticated, userRole } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(userRole)) {
    // Redirect to their respective home based on role if they try to access wrong route
    switch (userRole) {
      case 'student': return <Navigate to="/student-home" replace />;
      case 'teacher': return <Navigate to="/teacher-dashboard" replace />;
      case 'parent': return <Navigate to="/parent-dashboard" replace />;
      default: return <Navigate to="/" replace />;
    }
  }

  return children;
}