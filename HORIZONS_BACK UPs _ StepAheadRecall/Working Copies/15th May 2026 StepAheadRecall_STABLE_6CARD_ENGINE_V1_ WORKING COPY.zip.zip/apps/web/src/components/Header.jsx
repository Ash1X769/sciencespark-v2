import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { BrainCircuit, Menu, X, LogOut, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Header() {
  const { isAuthenticated, userRole, logout } = useAuth();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navLinks = [];

  if (isAuthenticated) {
    if (userRole === 'student') {
      navLinks.push({ name: 'Dashboard', path: '/student-home' });
      navLinks.push({ name: 'Mastered Cards', path: '/mastered-cards' });
    } else if (userRole === 'teacher') {
      navLinks.push({ name: 'Dashboard', path: '/teacher-dashboard' });
    } else if (userRole === 'parent') {
      navLinks.push({ name: 'Dashboard', path: '/parent-dashboard' });
    }
  }

  const handleLogout = () => {
    logout();
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary text-primary-foreground rounded-xl flex items-center justify-center shadow-sm">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <span className="font-bold text-xl tracking-tight hidden sm:block">Step Ahead Recall</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-semibold transition-colors hover:text-primary ${
                  location.pathname === link.path ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                {link.name}
              </Link>
            ))}

            <div className="flex items-center gap-3 ml-4">
              {!isAuthenticated ? (
                <>
                  <Link to="/login" className="text-sm font-semibold text-foreground hover:text-primary transition-colors">
                    Login
                  </Link>
                  <Button asChild className="rounded-full shadow-sm">
                    <Link to="/signup">Sign Up Free</Link>
                  </Button>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <Button asChild variant="ghost" size="icon" className="rounded-full">
                    <Link to="/settings" aria-label="Settings">
                      <Settings className="w-5 h-5 text-muted-foreground" />
                    </Link>
                  </Button>
                  <Button onClick={handleLogout} variant="outline" className="rounded-full shadow-sm">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              )}
            </div>
          </nav>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-b border-border">
          <div className="px-4 py-6 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`text-lg font-medium p-2 rounded-lg ${
                  location.pathname === link.path ? 'bg-primary/10 text-primary' : 'text-foreground'
                }`}
              >
                {link.name}
              </Link>
            ))}

            <div className="h-px bg-border my-2" />

            {!isAuthenticated ? (
              <div className="flex flex-col gap-3">
                <Button asChild variant="outline" className="w-full justify-start h-12 rounded-xl">
                  <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>Login</Link>
                </Button>
                <Button asChild className="w-full justify-start h-12 rounded-xl shadow-sm">
                  <Link to="/signup" onClick={() => setIsMobileMenuOpen(false)}>Sign Up Free</Link>
                </Button>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                <Button asChild variant="ghost" className="w-full justify-start h-12 rounded-xl">
                  <Link to="/settings" onClick={() => setIsMobileMenuOpen(false)}>
                    <Settings className="w-5 h-5 mr-3" /> Settings
                  </Link>
                </Button>
                <Button onClick={handleLogout} variant="destructive" className="w-full justify-start h-12 rounded-xl shadow-sm">
                  <LogOut className="w-5 h-5 mr-3" /> Logout
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}