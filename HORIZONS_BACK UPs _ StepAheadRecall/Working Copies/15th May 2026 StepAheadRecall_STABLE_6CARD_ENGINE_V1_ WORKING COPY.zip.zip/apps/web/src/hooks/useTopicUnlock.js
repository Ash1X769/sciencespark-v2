import { useState, useEffect } from 'react';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext';

const EXACT_TOPICS = [
  "Cell Structure",
  "Specialised Cells",
  "Transport in Cells",
  "Cell Division",
  "Stem Cells"
];

export function useTopicUnlock() {
  const { currentUser } = useAuth();
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!currentUser) return;
    let isMounted = true;

    async function checkUnlocks() {
      try {
        const fetchedTopics = await pb.collection('topics').getFullList({ $autoCancel: false });
        const allCards = await pb.collection('cards').getFullList({ $autoCancel: false });

        const fetchedCards = [];

        // Validate card existence and silently skip any that fail
        for (const c of allCards) {
          try {
            if (c.id && c.subject_id) {
              fetchedCards.push(c);
            }
          } catch (e) {
            // Silently skip deleted or invalid cards
          }
        }

        const topicsByName = new Map();
        fetchedTopics.forEach(t => {
          if (!t.name) return;
          const nameKey = t.name.trim().toLowerCase();
          
          const targetIndex = EXACT_TOPICS.findIndex(et => et.toLowerCase() === nameKey);
          if (targetIndex === -1) return;

          if (!topicsByName.has(nameKey)) {
            topicsByName.set(nameKey, { ...t, name: EXACT_TOPICS[targetIndex], allIds: [t.id] });
          } else {
            topicsByName.get(nameKey).allIds.push(t.id);
          }
        });
        const uniqueTopics = Array.from(topicsByName.values());

        const sortedTopics = uniqueTopics.sort((a, b) => {
          const idxA = EXACT_TOPICS.indexOf(a.name);
          const idxB = EXACT_TOPICS.indexOf(b.name);
          return idxA - idxB;
        });

        const topicsWithStats = sortedTopics.map(topic => {
          const topicCards = fetchedCards.filter(c => topic.allIds.includes(c.topic_id));
          
          const attemptedCards = topicCards.filter(c => c.attempted);
          const cardCount = topicCards.length;
          const avgStreak = cardCount > 0 
            ? topicCards.reduce((sum, c) => sum + (c.correct_streak || 0), 0) / cardCount
            : 0;

          let statusColor = "bg-destructive";
          if (avgStreak >= 4) statusColor = "bg-success";
          else if (avgStreak >= 2) statusColor = "bg-accent";

          return {
            ...topic,
            id: topic.allIds.join(','),
            originalId: topic.id,
            cardCount,
            attemptedCount: attemptedCards.length,
            statusColor
          };
        });

        if (topicsWithStats.length > 0 && !topicsWithStats[0].unlocked) {
          topicsWithStats[0].unlocked = true;
          await Promise.all(topicsWithStats[0].allIds.map(id => 
            pb.collection('topics').update(id, { unlocked: true }, { $autoCancel: false }).catch(() => {})
          ));
        }

        for (let i = 0; i < topicsWithStats.length - 1; i++) {
          const currentTopic = topicsWithStats[i];
          const nextTopic = topicsWithStats[i + 1];

          const allCardsAttempted = currentTopic.cardCount > 0 && currentTopic.attemptedCount >= currentTopic.cardCount;

          if (currentTopic.unlocked && allCardsAttempted && !nextTopic.unlocked) {
            nextTopic.unlocked = true;
            await Promise.all(nextTopic.allIds.map(id => 
              pb.collection('topics').update(id, { unlocked: true }, { $autoCancel: false }).catch(() => {})
            ));
          }
        }

        if (isMounted) {
          setTopics(topicsWithStats);
          setLoading(false);
        }
      } catch (error) {
        if (isMounted) setLoading(false);
      }
    }

    checkUnlocks();

    return () => { isMounted = false; };
  }, [currentUser]);

  const unlockedTopics = topics.filter(t => t.unlocked);
  const nextLockedTopic = topics.find(t => !t.unlocked) || null;
  
  const lastUnlocked = unlockedTopics.length > 0 ? unlockedTopics[unlockedTopics.length - 1] : null;
  const canUnlock = lastUnlocked && lastUnlocked.cardCount > 0 && lastUnlocked.attemptedCount >= lastUnlocked.cardCount;

  return {
    topics,
    unlockedTopics,
    nextLockedTopic,
    canUnlock,
    loading
  };
}