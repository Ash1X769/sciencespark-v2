
import { useState, useEffect, useCallback } from 'react';
import { localCards, getCardProgress } from '@/lib/localCards.js';
import { useAuth } from '@/contexts/AuthContext.jsx';

export const getStudentIdentifier = (currentUser) => {
  return currentUser?.id || currentUser?.name;
};

export const getLastSessionDate = (studentId) => {
  if (!studentId) return null;
  return localStorage.getItem(`stepAheadRecall_lastSessionDate_${studentId}`);
};

export const isSessionAvailableToday = (studentId) => {
  if (!studentId) return false;
  const lastDate = getLastSessionDate(studentId);
  const todayStr = new Date().toISOString().split('T')[0];
  return lastDate !== todayStr;
};

export const saveSessionDate = (studentId) => {
  if (!studentId) return;
  const todayStr = new Date().toISOString().split('T')[0];
  localStorage.setItem(`stepAheadRecall_lastSessionDate_${studentId}`, todayStr);
};

export const clearSessionDate = (studentId) => {
  if (!studentId) return;
  localStorage.removeItem(`stepAheadRecall_lastSessionDate_${studentId}`);
};

export function buildSession(studentIdentifier) {
  if (!studentIdentifier) return [];

  if (!isSessionAvailableToday(studentIdentifier)) {
    console.log('Session limit reached for today');
    return [];
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // 1. Fetch all cards with their current progress for this specific student
  const cardsWithProgress = localCards.map(card => ({
    ...card,
    progress: getCardProgress(card.id, studentIdentifier)
  }));

  // 2. Filter into groups
  const unseenCards = [];
  const dueCards = [];
  const blockedCards = [];

  cardsWithProgress.forEach(card => {
    if (card.progress.isNew === true || !card.progress.nextReviewDate) {
      unseenCards.push(card);
    } else {
      const reviewDate = new Date(card.progress.nextReviewDate);
      reviewDate.setHours(0, 0, 0, 0);
      
      if (reviewDate <= today) {
        dueCards.push(card);
      } else {
        blockedCards.push(card);
      }
    }
  });

  // 3. Select up to 6 cards (2 review cards if available + fill rest with unseen cards)
  const selectedDue = dueCards.slice(0, 2);
  const remainingForUnseen = 6 - selectedDue.length;
  const selectedUnseen = unseenCards.slice(0, remainingForUnseen);

  // Combine and ensure no blocked cards are included
  const combined = [...selectedUnseen, ...selectedDue];
  
  // Debug logging
  console.log(`Total cards: ${cardsWithProgress.length}`);
  console.log(`Unseen cards: ${unseenCards.length}`);
  console.log(`Due review cards: ${dueCards.length}`);
  console.log(`Blocked future cards: ${blockedCards.length}`);
  console.log(`Final session cards: ${combined.length}`);

  // 4. Apply light shuffle
  const shuffled = combined.sort(() => Math.random() - 0.5);

  return shuffled;
}

export function useSessionBuilder() {
  const { currentUser } = useAuth();
  const [sessionCards, setSessionCards] = useState([]);
  const [sessionComposition, setSessionComposition] = useState([]);
  const [loading, setLoading] = useState(true);

  const refreshSession = useCallback(() => {
    if (!currentUser) return;
    
    const studentIdentifier = getStudentIdentifier(currentUser);
    const selectedCards = buildSession(studentIdentifier);
    
    const newCount = selectedCards.filter(c => c.progress.isNew).length;
    const dueCount = selectedCards.length - newCount;
    
    const comp = [`${selectedCards.length} cards selected (${newCount} new, ${dueCount} review)`];

    setSessionCards(selectedCards);
    setSessionComposition(comp);
  }, [currentUser]);

  useEffect(() => {
    if (!currentUser) {
      setLoading(false);
      return;
    }

    refreshSession();
    setLoading(false);
  }, [currentUser, refreshSession]);

  return { sessionCards, sessionComposition, loading, refreshSession };
}
