import React, { createContext, useContext, useState, useEffect } from 'react';
import { pocketbaseClient as pb } from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

const DELETED_CARD_IDS = [
  '4zu8di93d5kt9sk', 
  'owg6z7y7jirfxxt', 
  'zcq779r1m9y1sc0', 
  'dcwquhcf2m6gt3k', 
  'z4twrelg3mj1h37', 
  'gq1lf4pvecwuy4p'
];

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [initialLoading, setInitialLoading] = useState(true);

  const cleanupLocalStorage = () => {
    try {
      let keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const val = localStorage.getItem(key);
          if (val && DELETED_CARD_IDS.some(id => val.includes(id))) {
            keysToRemove.push(key);
          }
        }
      }
      keysToRemove.forEach(k => {
        console.warn(`[Cleanup] Removing stale localStorage key '${k}' containing references to deleted cards.`);
        localStorage.removeItem(k);
      });
    } catch (e) {
      console.error("Failed to clean up localStorage", e);
    }
  };

  useEffect(() => {
    // Run one-time cleanup on startup to ensure no stale data persists
    cleanupLocalStorage();

    if (pb.authStore.isValid) {
      setCurrentUser(pb.authStore.model);
    }
    setInitialLoading(false);

    const unsubscribe = pb.authStore.onChange((token, model) => {
      setCurrentUser(model);
    });

    return () => unsubscribe();
  }, []);

  const ensureStudentProgress = async (userId) => {
    try {
      await pb.collection('student_progress').getFirstListItem(`user_id="${userId}"`, { $autoCancel: false });
    } catch (error) {
      // If not found, create it
      const pastDate = new Date();
      pastDate.setDate(pastDate.getDate() - 2); // Set to past so streak logic works correctly
      
      try {
        await pb.collection('student_progress').create({
          user_id: userId,
          streak: 0,
          cards_reviewed: 0,
          mastered_count: 0,
          date: pastDate.toISOString().replace('T', ' '),
        }, { $autoCancel: false });
      } catch (createError) {
        console.error("Failed to create initial student progress:", createError);
      }
    }
  };

  const login = async (email, password) => {
    try {
      const authData = await pb.collection('users').authWithPassword(email, password, { $autoCancel: false });
      setCurrentUser(authData.record);
      
      if (authData.record.role === 'student') {
        await ensureStudentProgress(authData.record.id);
      }
      
      return { success: true, role: authData.record.role };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const signup = async (data) => {
    try {
      await pb.collection('users').create({
        ...data,
        emailVisibility: true,
      }, { $autoCancel: false });
      
      // Auto login after signup
      return await login(data.email, data.password);
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  const logout = () => {
    pb.authStore.clear();
    setCurrentUser(null);
  };

  // Safe subscription check (in case user schema updates)
  const subscriptions = [];
  const hasActiveSubscription = (type) => true; // Bypass for demo purposes, would normally check pb.collection('subscriptions')

  const value = {
    currentUser,
    userRole: currentUser?.role || null,
    isAuthenticated: !!currentUser,
    login,
    signup,
    logout,
    subscriptions,
    hasActiveSubscription
  };

  if (initialLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}