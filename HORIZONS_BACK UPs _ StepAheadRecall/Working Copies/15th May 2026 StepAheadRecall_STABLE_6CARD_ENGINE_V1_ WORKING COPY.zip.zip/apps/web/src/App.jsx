import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { Toaster } from 'sonner';

import ProtectedRoute from '@/components/ProtectedRoute.jsx';
import ScrollToTop from '@/components/ScrollToTop.jsx';

import HomePage from '@/pages/HomePage.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import SignupPage from '@/pages/SignupPage.jsx';
import StudentHome from '@/pages/StudentHome.jsx';
import SessionPage from '@/pages/SessionPage.jsx';
import SessionCompletePage from '@/pages/SessionCompletePage.jsx';
import MasteredCardsPage from '@/pages/MasteredCardsPage.jsx';
import TeacherDashboard from '@/pages/TeacherDashboard.jsx';
import ParentDashboard from '@/pages/ParentDashboard.jsx';
import SettingsPage from '@/pages/SettingsPage.jsx';

function App() {
  return (
    <AuthProvider>
      <Router>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />

          {/* Student Routes */}
          <Route path="/student-home" element={<ProtectedRoute allowedRoles={['student']}><StudentHome /></ProtectedRoute>} />
          <Route path="/session" element={<ProtectedRoute allowedRoles={['student']}><SessionPage /></ProtectedRoute>} />
          <Route path="/session-complete" element={<ProtectedRoute allowedRoles={['student']}><SessionCompletePage /></ProtectedRoute>} />
          <Route path="/mastered-cards" element={<ProtectedRoute allowedRoles={['student']}><MasteredCardsPage /></ProtectedRoute>} />

          {/* Teacher Routes */}
          <Route path="/teacher-dashboard" element={<ProtectedRoute allowedRoles={['teacher']}><TeacherDashboard /></ProtectedRoute>} />

          {/* Parent Routes */}
          <Route path="/parent-dashboard" element={<ProtectedRoute allowedRoles={['parent']}><ParentDashboard /></ProtectedRoute>} />

          {/* General Protected Route */}
          <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />

          {/* Fallback Route */}
          <Route path="*" element={<Navigate to="/student-home" replace />} />
        </Routes>
        <Toaster position="top-center" richColors />
      </Router>
    </AuthProvider>
  );
}

export default App;