import express from 'express';
import Stripe from 'stripe';
import pocketbaseClient from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Create Checkout Session
router.post('/create-checkout', async (req, res) => {
  const { amount, productName, subscriptionType, billingPeriod, successUrl, cancelUrl } = req.body;

  if (!amount || !productName || !successUrl || !cancelUrl) {
    return res.status(400).json({ error: 'Missing required fields: amount, productName, successUrl, cancelUrl' });
  }

  const isRecurring = subscriptionType && billingPeriod;
  const mode = isRecurring ? 'subscription' : 'payment';

  const lineItem = {
    price_data: {
      currency: 'gbp',
      product_data: { name: productName },
      unit_amount: Math.round(amount * 100), // Convert to pence
    },
    quantity: 1,
  };

  if (isRecurring) {
    lineItem.price_data.recurring = {
      interval: billingPeriod === 'yearly' ? 'year' : 'month',
    };
  }

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [lineItem],
    mode,
    success_url: successUrl,
    cancel_url: cancelUrl,
    ...(isRecurring && {
      metadata: {
        subscriptionType,
        billingPeriod,
      },
    }),
  });

  res.json({ url: session.url });
});

// Retrieve session details
router.get('/session/:sessionId', async (req, res) => {
  const { sessionId } = req.params;

  if (!sessionId) {
    return res.status(400).json({ error: 'sessionId is required' });
  }

  const session = await stripe.checkout.sessions.retrieve(sessionId);

  res.json({
    id: session.id,
    status: session.payment_status,
    amountTotal: session.amount_total,
    customerEmail: session.customer_details?.email,
    subscriptionType: session.metadata?.subscriptionType,
    billingPeriod: session.metadata?.billingPeriod,
  });
});

// Verify payment and create subscription
router.post('/subscription/verify', async (req, res) => {
  const { sessionId, userId } = req.body;

  if (!sessionId || !userId) {
    return res.status(400).json({ error: 'Missing required fields: sessionId, userId' });
  }

  const session = await stripe.checkout.sessions.retrieve(sessionId);

  if (session.payment_status !== 'paid') {
    throw new Error(`Payment not completed. Status: ${session.payment_status}`);
  }

  const subscriptionType = session.metadata?.subscriptionType || 'chatbot';
  const billingPeriod = session.metadata?.billingPeriod || 'monthly';

  // Calculate expiry date
  const expiryDate = new Date();
  if (billingPeriod === 'yearly') {
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);
  } else {
    expiryDate.setMonth(expiryDate.getMonth() + 1);
  }

  // Create subscription record in PocketBase
  const subscription = await pocketbaseClient.collection('subscriptions').create({
    userId,
    subscriptionType,
    billingPeriod,
    expiryDate: expiryDate.toISOString(),
    status: 'active',
    stripeSessionId: sessionId,
  });

  logger.info(`Subscription created for user ${userId}: ${subscription.id}`);

  res.json({
    success: true,
    subscriptionId: subscription.id,
  });
});

export default router;